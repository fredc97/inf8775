# Closest points

Ce code en python permet de trouver la plus petite distance entre 2 points sur un plan. Les points sont générés aléatoirement sur un plan de taille 1,000,000 * 1,000,000.

Ce code est une aide au TP1 du cours INF8775 de Polytechnique Montréal.

**ATTENTION :** Dans votre TP vous devez utiliser le générateur gen.py
pour générer des points. Si vous souhaitez utiliser une partie de ce code, vous devez le modifier pour importer les points depuis les fichiers générés avec le générateur gen.py fourni dans l'énoncé du TP.
De plus, vous devez faire en sorte que l'interface du tp.sh soit
compatible avec ce code (par exemple l'utilisation de flag -e, -a, -p et -t)).