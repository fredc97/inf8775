#include <cstring>
#include <iostream>
#include <fstream>
#include <float.h> 
#include <stdlib.h> 
#include <math.h> 
using namespace std; 
std::ifstream infile("1000-1.txt");

int z = 0;

  struct Point 
{ 
    int x, y; 
}; 
  
float dist(Point p1, Point p2) 
{ 
    return sqrt( (p1.x - p2.x)*(p1.x - p2.x) + 
                 (p1.y - p2.y)*(p1.y - p2.y)); 
} 
  
float bruteForce(Point P[], int n) 
{ 
    float min = FLT_MAX; 
    for (int i = 0; i < n; ++i) {
        for (int j = i+1; j < n; ++j) {
            if (dist(P[i], P[j]) < min) 
                min = dist(P[i], P[j]);
         }
     } 
  
    return min; 
} 


int main(int argc, char* argv[]) {
  char* fn = nullptr;
  bool show_p = false;
  bool show_t = false;
  
	
Point point;
Point points[1000];

while (infile >> point.x >> point.y)
{
		points[z].x =  point.x ;
		points[z].y = point.y;
		z++;	
}



    for (int i=1; i<argc; i++) {
    if (!strcmp(argv[i], "-e")) {
      i++;
      fn = argv[i];
    }
    else if (!strcmp(argv[i], "-p")) {
		
      show_p = true;
    }
    else if (!strcmp(argv[i], "-t")) {
	
      show_t = true;
    }
    else if (!strcmp(argv[i], "-a")) {

      i++;
      if (!strcmp(argv[i], "brute")) {
	// todo
	// balise pour le temps 
	// p en bas cest le resultat de lalgo force brute
	// t en bas ben c le temps
	bruteForce(points, 1000);
      }
      else if (!strcmp(argv[i], "seuil")) {
		  cout<< "seuil";
	// todo
      }
      else {
	cout << "Erreur: Algo inconnu" << endl;
	return -1;
      }
    }
  }

  if (show_p) {
    cout << "2.5" << endl; // Exemple de distance, ici une valeur bidon
  }
  if (show_t) {
    cout << "3.42" << endl; // Exemple de temps, ici une valeur bidon
  }
  
  return 0; 
} 
